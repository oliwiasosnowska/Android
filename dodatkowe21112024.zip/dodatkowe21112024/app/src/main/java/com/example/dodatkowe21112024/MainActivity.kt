package com.example.dodatkowe21112024

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.RadioButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.dodatkowe21112024.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(LayoutInflater.from(this))
        setContentView(binding.root)
        val listaObrazkow = arrayListOf(R.drawable.kot, R.drawable.pies, R.drawable.piesdrugi)
        var index = 0
        val listaIndeksow = arrayListOf(binding.radioButton.id, binding.radioButton2.id, binding.radioButton3.id)
        with(binding){
            radioGrupa.check(listaIndeksow[index])
            buttonNext.setOnClickListener {
                index = (index + 1) % listaObrazkow.size
                radioGrupa.check(listaIndeksow[index])
                imageView.setImageResource(listaObrazkow[index])
            }
            buttonPrev.setOnClickListener{
                index = (index - 1+listaObrazkow.size) % listaObrazkow.size
                imageView.setImageResource(listaObrazkow[index])
                radioGrupa.check(listaIndeksow[index])

            }
            radioGrupa.setOnCheckedChangeListener { radioGroup, i ->
                var radio = findViewById<RadioButton>(i).text.toString()
                if( radio == "kot"){
                    index = 0
                    imageView.setImageResource(listaObrazkow[index])
                }
                else if (radio == "pies"){
                    index = 1
                    imageView.setImageResource(listaObrazkow[index])

                }
                else{
                    index = 2
                    imageView.setImageResource(listaObrazkow[index])
                }
            }
        }

    }
}