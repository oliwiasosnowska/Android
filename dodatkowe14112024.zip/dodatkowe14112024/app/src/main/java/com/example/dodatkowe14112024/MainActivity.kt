package com.example.dodatkowe14112024

import android.content.res.Resources
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.LayoutInflaterCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.get
import com.example.dodatkowe14112024.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(LayoutInflater.from(this))
        setContentView(binding.root)
        val listaObrazkow = arrayListOf(R.drawable.pies,R.drawable.piesdrugi,R.drawable.kot)
        var indeks = 0
        val max = Resources.getSystem().getDisplayMetrics().widthPixels
        val min = max / 2
        binding.seekBar.max = max
        binding.seekBar.min = min
        binding.seekBar.progress = max
        with(binding){
            Toast.makeText(this@MainActivity,max.toString(),Toast.LENGTH_SHORT).show()
            buttonNext.setOnClickListener{
                indeks = (indeks +1) % listaObrazkow.size
                imageView.setImageResource(listaObrazkow[indeks])
            }
            buttonPrev.setOnClickListener{
                indeks = (indeks - 1+listaObrazkow.size) %listaObrazkow.size
                imageView.setImageResource(listaObrazkow[indeks])
            }
            seekBar.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
                override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                    imageView.layoutParams.width = seekBar.progress.toInt()
                    textViewProgress.text = seekBar.progress.toString()
                }

                override fun onStartTrackingTouch(p0: SeekBar?) {
                }

                override fun onStopTrackingTouch(p0: SeekBar?) {
                }
            })

        }


    }
}