package com.example.dodatkowe

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.dodatkowe.databinding.ActivityMainBinding
import com.example.dodatkowe.databinding.ActivitySecondBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val binding = ActivityMainBinding.inflate(LayoutInflater.from(this))
        val binding2 = ActivitySecondBinding.inflate(LayoutInflater.from(this))
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        with(binding){
            buttonPrzejdz.setOnClickListener{
                setContentView(R.layout.activity_second)
                setContentView(binding2.root)
            }
            checkBox.setOnClickListener{
                if (checkBox.isChecked){
                    buttonTrzeci.visibility = View.VISIBLE
                }
                else{
                    buttonTrzeci.visibility = View.GONE
                }
            }

        }
        with(binding2){
            buttonWroc.setOnClickListener{
                setContentView(R.layout.activity_main)
            }
        }

    }
}